import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Signal from "@/components/Signal";
import Writing from "@/components/Writing";
import Works from "@/components/Works";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import RevealOnScroll from "@/components/RevealOnScroll";

export default function Page() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Signal />
        <Writing />
        <Works />
        <Contact />
        <Footer />
      </main>
      <RevealOnScroll />
    </>
  );
}
