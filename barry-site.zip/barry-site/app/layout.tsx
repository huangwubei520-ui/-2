import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BARRY 百里 / 黄吴备 — AI Product Manager",
  description:
    "AI 产品经理。用产品思维和 Vibe Coding,把 AI 想法快速变成可用原型。",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin=""
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Geist:wght@300;400;500;600;700&family=Geist+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans bg-bg text-fg">{children}</body>
    </html>
  );
}
