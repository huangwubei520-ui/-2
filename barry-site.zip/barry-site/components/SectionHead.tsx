export default function SectionHead({
  zh,
  en,
  index,
}: {
  zh: string;
  en: string;
  index: string;
}) {
  return (
    <div className="reveal mb-14 sm:mb-20">
      {/* 顶部细分割线 + 编号 + 英文 */}
      <div className="flex items-baseline justify-between font-mono text-[11px] tracking-[0.12em] uppercase text-fg-3 mb-8 sm:mb-10">
        <span>{index}</span>
        <span>{en}</span>
      </div>
      <div className="h-px bg-line w-full mb-10 sm:mb-14" />
      <h2 className="text-[clamp(44px,8vw,104px)] font-medium leading-[0.95] tracking-[-0.04em]">
        {zh}
      </h2>
    </div>
  );
}
