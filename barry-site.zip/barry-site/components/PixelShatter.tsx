"use client";

import { useEffect, useRef } from "react";

/**
 * PixelShatter
 *
 * 把传入的文字渲染到 canvas,采样像素后变成一群"粒子方块"。
 * 鼠标靠近时粒子被推开(分解),离开后粒子用弹簧回弹到原位(凝聚)。
 *
 * 灵感来自 Vercel Ship 的 hover 解构效果。
 */
type Props = {
  text: string;
  italic?: boolean;
  className?: string;
  /** 字号(像素),响应式由外部 wrapper 控制 */
  fontSize?: number;
  /** 像素粒度,值越小越细密但越费性能 */
  cell?: number;
  /** 鼠标影响半径 */
  radius?: number;
  /** 推开强度 */
  force?: number;
  /** 粒子颜色 */
  color?: string;
  /** 字重 */
  weight?: number;
};

type Particle = {
  ox: number; // 原始 x
  oy: number;
  x: number; // 当前 x
  y: number;
  vx: number;
  vy: number;
  size: number;
};

export default function PixelShatter({
  text,
  italic = false,
  className = "",
  fontSize = 220,
  cell = 6,
  radius = 110,
  force = 2.2,
  color = "#ffffff",
  weight = 500,
}: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({
    x: -9999,
    y: -9999,
    active: false,
  });
  const rafRef = useRef<number | null>(null);
  const dprRef = useRef(1);

  // 采样:把文字画到离屏 canvas 上,逐 cell 采样不透明像素,生成粒子
  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;

    const setup = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      dprRef.current = dpr;

      // 离屏 canvas 用于测量 + 采样
      const off = document.createElement("canvas");
      const offCtx = off.getContext("2d", { willReadFrequently: true })!;
      const fontStack =
        '"Geist","-apple-system","PingFang SC","Microsoft YaHei",sans-serif';
      const fontStr = `${italic ? "italic " : ""}${weight} ${fontSize}px ${fontStack}`;
      offCtx.font = fontStr;
      const metrics = offCtx.measureText(text);
      const ascent = metrics.actualBoundingBoxAscent || fontSize * 0.8;
      const descent = metrics.actualBoundingBoxDescent || fontSize * 0.2;
      const textW = Math.ceil(metrics.width);
      const textH = Math.ceil(ascent + descent);

      const padX = 40;
      const padY = 30;
      const W = textW + padX * 2;
      const H = textH + padY * 2;

      off.width = W;
      off.height = H;
      const ctx2 = off.getContext("2d", { willReadFrequently: true })!;
      ctx2.font = fontStr;
      ctx2.fillStyle = "#fff";
      ctx2.textBaseline = "alphabetic";
      ctx2.fillText(text, padX, padY + ascent);

      const img = ctx2.getImageData(0, 0, W, H).data;

      // 采样
      const parts: Particle[] = [];
      for (let y = 0; y < H; y += cell) {
        for (let x = 0; x < W; x += cell) {
          // 取 cell 中心点的 alpha
          const cx = Math.min(x + (cell >> 1), W - 1);
          const cy = Math.min(y + (cell >> 1), H - 1);
          const idx = (cy * W + cx) * 4;
          const a = img[idx + 3];
          if (a > 128) {
            parts.push({
              ox: x,
              oy: y,
              x: x + (Math.random() - 0.5) * 40,
              y: y + (Math.random() - 0.5) * 40,
              vx: (Math.random() - 0.5) * 0.5,
              vy: (Math.random() - 0.5) * 0.5,
              size: cell - 1,
            });
          }
        }
      }
      particlesRef.current = parts;

      // 真正显示用的 canvas
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      const ctx = canvas.getContext("2d")!;
      ctx.scale(dpr, dpr);
    };

    setup();

    // 监听字号变化(响应式)— 当 wrapper 宽度变化时不重设,这里 fontSize 由 props 控制
    const ro = new ResizeObserver(() => {
      setup();
    });
    ro.observe(wrap);

    return () => ro.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, italic, fontSize, cell, weight]);

  // 动画循环
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;

    const loop = () => {
      const parts = particlesRef.current;
      const m = mouseRef.current;
      const W = canvas.width / dprRef.current;
      const H = canvas.height / dprRef.current;

      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = color;

      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];

        if (m.active) {
          const dx = p.x - m.x;
          const dy = p.y - m.y;
          const d2 = dx * dx + dy * dy;
          const r2 = radius * radius;
          if (d2 < r2 && d2 > 0.01) {
            const d = Math.sqrt(d2);
            const f = ((radius - d) / radius) * force;
            p.vx += (dx / d) * f;
            p.vy += (dy / d) * f;
          }
        }

        // 弹簧回到原点
        const sx = (p.ox - p.x) * 0.06;
        const sy = (p.oy - p.y) * 0.06;
        p.vx = (p.vx + sx) * 0.86;
        p.vy = (p.vy + sy) * 0.86;
        p.x += p.vx;
        p.y += p.vy;

        ctx.fillRect(p.x, p.y, p.size, p.size);
      }

      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [color, radius, force]);

  // 鼠标 / 触摸交互
  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;

    const onMove = (e: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - r.left,
        y: e.clientY - r.top,
        active: true,
      };
    };
    const onLeave = () => {
      mouseRef.current.active = false;
      mouseRef.current.x = -9999;
      mouseRef.current.y = -9999;
    };
    const onTouch = (e: TouchEvent) => {
      const t = e.touches[0];
      if (!t) return;
      const r = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: t.clientX - r.left,
        y: t.clientY - r.top,
        active: true,
      };
    };

    wrap.addEventListener("mousemove", onMove);
    wrap.addEventListener("mouseleave", onLeave);
    wrap.addEventListener("touchmove", onTouch, { passive: true });
    wrap.addEventListener("touchend", onLeave);

    return () => {
      wrap.removeEventListener("mousemove", onMove);
      wrap.removeEventListener("mouseleave", onLeave);
      wrap.removeEventListener("touchmove", onTouch);
      wrap.removeEventListener("touchend", onLeave);
    };
  }, []);

  return (
    <div ref={wrapRef} className={`inline-block leading-none ${className}`}>
      <canvas
        ref={canvasRef}
        aria-label={text}
        role="img"
        className="block max-w-full"
      />
    </div>
  );
}
