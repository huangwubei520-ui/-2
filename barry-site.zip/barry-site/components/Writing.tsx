import SectionHead from "./SectionHead";

const articles = [
  {
    num: "001",
    title: "人人都是产品经理 · 作者主页",
    desc: "在国内最大的产品经理社区分享对 AI 产品、用户体验与方法论的思考。",
    tag: "woshipm",
    href: "https://www.woshipm.com/u/1678627",
  },
  {
    num: "002",
    title: "微信公众号文章",
    desc: "长文记录,从 AI 产品真实落地场景出发,聊产品设计、模型选型与心得。",
    tag: "WeChat",
    href: "https://mp.weixin.qq.com/s/pEWVibGX2VMlJsvAeioIOQ",
  },
  {
    num: "003",
    title: "更多笔记正在路上",
    desc: "下一篇正在打磨——关于 Vibe Coding 工作流与 prompt-first 产品设计。",
    tag: "draft",
    href: null,
  },
];

export default function Writing() {
  return (
    <section id="writing" className="py-28 sm:py-36 border-b border-line">
      <div className="wrap">
        <SectionHead zh="文章" en="Selected Writing" index="02 / NOTES" />

        <div className="reveal border-t border-line">
          {articles.map((a) =>
            a.href ? (
              <a
                key={a.num}
                href={a.href}
                target="_blank"
                rel="noopener noreferrer"
                className="group grid grid-cols-[60px_1fr_auto_auto] sm:grid-cols-[100px_1fr_auto_auto] items-center gap-4 sm:gap-10 py-7 sm:py-9 border-b border-line transition-colors duration-300 hover:bg-white/[0.02] px-2 sm:px-4 -mx-2 sm:-mx-4 rounded-md"
              >
                <span className="font-mono text-xs text-fg-3 tracking-wider">
                  {a.num}
                </span>
                <div className="min-w-0">
                  <h3 className="text-lg sm:text-2xl font-normal tracking-[-0.02em] mb-1 truncate">
                    {a.title}
                  </h3>
                  <p className="text-sm text-fg-2 line-clamp-1 hidden sm:block">
                    {a.desc}
                  </p>
                </div>
                <span className="hidden sm:inline font-mono text-[11px] text-fg-2 border border-line px-2.5 py-1 rounded-full tracking-wider">
                  {a.tag}
                </span>
                <span className="font-mono text-lg text-fg-3 transition-all duration-300 group-hover:translate-x-1 group-hover:text-fg">
                  →
                </span>
              </a>
            ) : (
              <div
                key={a.num}
                className="grid grid-cols-[60px_1fr_auto_auto] sm:grid-cols-[100px_1fr_auto_auto] items-center gap-4 sm:gap-10 py-7 sm:py-9 border-b border-line opacity-50 px-2 sm:px-4 -mx-2 sm:-mx-4"
              >
                <span className="font-mono text-xs text-fg-3 tracking-wider">
                  {a.num}
                </span>
                <div className="min-w-0">
                  <h3 className="text-lg sm:text-2xl font-normal tracking-[-0.02em] mb-1">
                    {a.title}
                  </h3>
                  <p className="text-sm text-fg-2 line-clamp-1 hidden sm:block">
                    {a.desc}
                  </p>
                </div>
                <span className="hidden sm:inline font-mono text-[11px] text-fg-3 border border-line px-2.5 py-1 rounded-full tracking-wider">
                  {a.tag}
                </span>
                <span className="font-mono text-lg text-fg-3">·</span>
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
}
