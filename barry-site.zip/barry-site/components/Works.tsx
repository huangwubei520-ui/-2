"use client";

import SectionHead from "./SectionHead";

const slots = [
  {
    code: "W—01",
    zh: "Prompt-first 工具",
    en: "Prompt-first tool",
  },
  {
    code: "W—02",
    zh: "Agent 工作流",
    en: "Agent workflow",
  },
  {
    code: "W—03",
    zh: "AI 草稿本",
    en: "AI sketchpad",
  },
];

export default function Works() {
  return (
    <section id="works" className="py-28 sm:py-36 border-b border-line">
      <div className="wrap">
        <SectionHead zh="作品" en="Works · Coming Soon" index="03 / SHIPPING" />

        <p className="reveal text-base sm:text-lg text-fg-2 max-w-2xl mb-14 sm:mb-20 leading-relaxed">
          正在用 Vibe Coding 把若干想法做成可点开的原型。
          <br className="hidden sm:block" />
          预计很快上线第一个。
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-0 border-t border-l border-line">
          {slots.map((s, i) => (
            <div
              key={s.code}
              className="reveal group relative bg-bg aspect-[4/3] flex flex-col justify-between p-6 sm:p-8 overflow-hidden transition-colors duration-300 hover:bg-elev border-r border-b border-line"
              onMouseMove={(e) => {
                const r = (
                  e.currentTarget as HTMLDivElement
                ).getBoundingClientRect();
                (e.currentTarget as HTMLDivElement).style.setProperty(
                  "--mx",
                  `${e.clientX - r.left}px`
                );
                (e.currentTarget as HTMLDivElement).style.setProperty(
                  "--my",
                  `${e.clientY - r.top}px`
                );
              }}
              style={{
                backgroundImage: `radial-gradient(360px circle at var(--mx, 50%) var(--my, 0%), rgba(255,255,255,0.05), transparent 40%)`,
              }}
            >
              {/* 像素方块装饰 */}
              <div className="absolute inset-0 opacity-[0.08] pointer-events-none">
                <svg
                  className="w-full h-full"
                  viewBox="0 0 100 100"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <pattern
                      id={`px-${i}`}
                      x="0"
                      y="0"
                      width="6"
                      height="6"
                      patternUnits="userSpaceOnUse"
                    >
                      <rect x="0" y="0" width="2" height="2" fill="#fff" />
                    </pattern>
                  </defs>
                  <rect width="100" height="100" fill={`url(#px-${i})`} />
                </svg>
              </div>

              {/* 顶部:编号 + 状态 */}
              <div className="flex items-center justify-between relative z-10">
                <span className="font-mono text-[11px] text-fg-3 tracking-[0.12em] uppercase">
                  {s.code}
                </span>
                <span className="font-mono text-[10px] text-fg-3 border border-line px-2 py-0.5 rounded-full tracking-wider">
                  COMING SOON
                </span>
              </div>

              <div className="relative z-10">
                <div className="text-2xl sm:text-3xl font-medium tracking-[-0.02em] text-fg-2 group-hover:text-fg transition-colors leading-tight">
                  {s.zh}
                </div>
                <div className="font-mono text-[11px] text-fg-3 mt-2 tracking-wider">
                  {s.en} · idx {String(i + 1).padStart(2, "0")}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
