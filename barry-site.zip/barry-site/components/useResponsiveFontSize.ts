"use client";

import { useEffect, useState } from "react";

/**
 * 根据视口宽度返回字号,把 clamp(min, vw*ratio, max) 的逻辑搬到 JS。
 * 因为 canvas 渲染需要明确数值,不能用 clamp() CSS。
 */
export function useResponsiveFontSize(
  min: number,
  ratioVw: number,
  max: number
) {
  const [size, setSize] = useState(min);

  useEffect(() => {
    const compute = () => {
      const vw = window.innerWidth;
      const px = Math.min(max, Math.max(min, (vw * ratioVw) / 100));
      setSize(Math.round(px));
    };
    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  }, [min, ratioVw, max]);

  return size;
}
