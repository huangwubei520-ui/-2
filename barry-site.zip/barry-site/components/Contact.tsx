import SectionHead from "./SectionHead";

const links = [
  {
    platform: "WeChat 公众号",
    zh: "微信公众号",
    label: "记录 AI 产品落地的长文与思考",
    href: "https://mp.weixin.qq.com/s/pEWVibGX2VMlJsvAeioIOQ",
  },
  {
    platform: "woshipm",
    zh: "人人都是产品经理",
    label: "完整作者主页与文章合集",
    href: "https://www.woshipm.com/u/1678627",
  },
];

export default function Contact() {
  return (
    <section id="contact" className="py-28 sm:py-36">
      <div className="wrap">
        <SectionHead zh="联系" en="Get in Touch" index="04 / CONTACT" />

        <p className="reveal text-[clamp(22px,3vw,36px)] leading-snug tracking-[-0.02em] max-w-4xl mb-14 sm:mb-20">
          有合作、想法或者单纯想聊聊 AI 产品?
          <br className="hidden sm:block" />
          <span className="text-fg-3">通过下面任意一个渠道找到我。</span>
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-0 border-t border-l border-line">
          {links.map((l) => (
            <a
              key={l.platform}
              href={l.href}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal group bg-bg p-8 sm:p-12 flex flex-col justify-between min-h-[220px] sm:min-h-[280px] transition-colors duration-300 hover:bg-elev border-r border-b border-line"
            >
              <div className="flex items-start justify-between">
                <span className="font-mono text-[11px] text-fg-3 tracking-[0.12em] uppercase">
                  {l.platform}
                </span>
                <span className="text-2xl text-fg-2 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1">
                  ↗
                </span>
              </div>
              <div className="mt-10">
                <div className="text-2xl sm:text-[34px] font-medium tracking-[-0.02em] leading-tight">
                  {l.zh}
                </div>
                <div className="text-sm text-fg-2 mt-3 leading-relaxed">
                  {l.label}
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
