import SectionHead from "./SectionHead";

const signals = [
  {
    num: "01",
    zh: "AI 产品经理",
    en: "AI Product Manager",
    desc: "把模糊需求拆成清晰的产品定义,排优先级,小步快跑地交付。",
  },
  {
    num: "02",
    zh: "Vibe Coding",
    en: "Vibe Coding",
    desc: "用 AI 辅助编码,把脑里的产品想法在几小时内变成能跑的 demo。",
  },
  {
    num: "03",
    zh: "Prompt 设计",
    en: "Prompt Design",
    desc: "把 prompt 当作产品规格来写——明确输入、输出、约束、评估。",
  },
  {
    num: "04",
    zh: "产品策略",
    en: "Product Strategy",
    desc: "判断 AI 在哪里能省时间、消除摩擦,或者创造一种全新的能力。",
  },
];

export default function Signal() {
  return (
    <section id="signal" className="py-28 sm:py-36 border-b border-line">
      <div className="wrap">
        <SectionHead zh="信号源" en="About Signal" index="01 / WHO" />

        <p className="reveal text-[clamp(22px,3.2vw,38px)] leading-snug font-normal tracking-[-0.02em] max-w-4xl mb-16 sm:mb-20">
          用<span className="text-fg-3"> 产品思维 </span>和
          <span className="text-fg-3"> Vibe Coding</span>,
          <br className="hidden sm:block" />
          把 AI 想法快速变成可用原型。
        </p>

        {/* 关键词网格,带 grid 线 */}
        <div className="relative reveal">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border-t border-l border-line">
            {signals.map((s) => (
              <div
                key={s.num}
                className="group relative p-7 sm:p-8 border-r border-b border-line bg-bg transition-colors duration-300 hover:bg-elev min-h-[220px] flex flex-col"
              >
                {/* 顶部:编号 + 英文 */}
                <div className="flex items-baseline justify-between font-mono text-[10px] tracking-[0.12em] uppercase text-fg-3 mb-10">
                  <span>{s.num}</span>
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {s.en}
                  </span>
                </div>

                {/* 中文关键词 */}
                <h3 className="text-2xl sm:text-[28px] font-medium tracking-[-0.02em] mb-4 leading-tight">
                  {s.zh}
                </h3>
                <p className="text-sm text-fg-2 leading-relaxed mt-auto">
                  {s.desc}
                </p>

                {/* hover 时左上角出现一个小方块,呼应像素感 */}
                <span className="absolute top-3 right-3 w-1.5 h-1.5 bg-fg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
