export default function Footer() {
  return (
    <footer className="border-t border-line py-12 sm:py-16">
      <div className="wrap flex justify-between items-baseline flex-wrap gap-6 font-mono text-[11px] text-fg-3 tracking-[0.1em] uppercase">
        <span>© 2026 BARRY / 黄吴备</span>
        <span>Built with restraint · Next.js + Tailwind</span>
      </div>
    </footer>
  );
}
