"use client";

import LocalClock from "./LocalClock";
import PixelShatter from "./PixelShatter";
import { useResponsiveFontSize } from "./useResponsiveFontSize";

export default function Hero() {
  // 字号:窄屏不小于 72px,宽屏最大 260px
  const size1 = useResponsiveFontSize(72, 17, 260);
  const size2 = useResponsiveFontSize(72, 17, 260);

  return (
    <header
      id="top"
      className="relative pt-[180px] sm:pt-[220px] pb-32 sm:pb-40 border-b border-line overflow-hidden"
    >
      {/* 增强网格背景 */}
      <div
        aria-hidden
        className="absolute inset-0 pointer-events-none opacity-[0.6]"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px)
          `,
          backgroundSize: "80px 80px",
          maskImage:
            "radial-gradient(ellipse 80% 60% at 50% 40%, black 30%, transparent 80%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 80% 60% at 50% 40%, black 30%, transparent 80%)",
        }}
      />

      <div className="wrap hero-anim relative">
        {/* Eyebrow */}
        <div className="font-mono text-[11px] sm:text-xs text-fg-2 tracking-[0.12em] uppercase flex items-center gap-3 mb-12 sm:mb-16 flex-wrap">
          <span className="w-6 h-px bg-fg-2" />
          AI Product Manager · 黄吴备 / BARRY 百里
          <span className="hidden sm:inline-block text-fg-3 ml-1">· 2026</span>
        </div>

        {/* 超大中文主标 + PixelShatter */}
        <div className="select-none">
          <div className="block">
            <PixelShatter
              text="把 AI 想法"
              fontSize={size1}
              weight={500}
              cell={Math.max(4, Math.round(size1 / 36))}
              radius={Math.round(size1 * 0.55)}
              force={2.4}
            />
          </div>
          <div className="block mt-2 sm:mt-4">
            <PixelShatter
              text="变成可用原型"
              italic
              fontSize={size2}
              weight={300}
              cell={Math.max(4, Math.round(size2 / 36))}
              radius={Math.round(size2 * 0.55)}
              force={2.4}
              color="rgba(255,255,255,0.55)"
            />
          </div>
        </div>

        {/* 副标说明 */}
        <p className="mt-12 sm:mt-16 max-w-2xl text-base sm:text-lg text-fg-2 leading-relaxed">
          AI 产品经理 · 用产品思维和{" "}
          <span className="text-fg font-mono text-[0.92em] border border-line px-1.5 py-0.5 rounded-md">
            Vibe Coding
          </span>{" "}
          把模糊想法在一个下午变成能跑的原型。
        </p>

        {/* Meta 四宫格 */}
        <div className="mt-14 sm:mt-20 grid grid-cols-2 sm:grid-cols-4 gap-x-6 sm:gap-x-10 gap-y-7 font-mono text-[13px] text-fg-2">
          <MetaItem label="状态 / status">
            <span className="inline-block w-[7px] h-[7px] bg-white rounded-full mr-2 -translate-y-px animate-pulse" />
            开放合作
          </MetaItem>
          <MetaItem label="角色 / role">AI Product Manager</MetaItem>
          <MetaItem label="工具箱 / toolkit">Product · Vibe Coding</MetaItem>
          <MetaItem label="本地时间 / local">
            <LocalClock />
          </MetaItem>
        </div>

        {/* 提示线 */}
        <div className="mt-16 sm:mt-24 flex items-center gap-3 font-mono text-[11px] text-fg-3 tracking-[0.12em] uppercase">
          <span className="w-12 h-px bg-line" />
          鼠标滑过标题 · 字会分解成像素
          <span className="flex-1 h-px bg-line" />
        </div>
      </div>
    </header>
  );
}

function MetaItem({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-fg-3 text-[10px] uppercase tracking-[0.12em]">
        {label}
      </span>
      <span className="text-fg text-sm">{children}</span>
    </div>
  );
}
