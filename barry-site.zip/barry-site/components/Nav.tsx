export default function Nav() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-black/60 border-b border-line">
      <div className="wrap h-14 flex items-center justify-between">
        <a
          href="#top"
          className="font-mono text-[13px] font-medium tracking-wide flex items-center gap-2.5"
        >
          <span className="inline-block w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
          BARRY / 黄吴备
        </a>
        <div className="flex gap-4 sm:gap-8 text-[13px] text-fg-2">
          <a
            href="#signal"
            className="hover:text-fg transition-colors duration-200"
          >
            信号
          </a>
          <a
            href="#writing"
            className="hover:text-fg transition-colors duration-200"
          >
            文章
          </a>
          <a
            href="#works"
            className="hidden sm:inline hover:text-fg transition-colors duration-200"
          >
            作品
          </a>
          <a
            href="#contact"
            className="hover:text-fg transition-colors duration-200"
          >
            联系
          </a>
        </div>
      </div>
    </nav>
  );
}
