# BARRY / 黄吴备 — 个人网站 Demo

Next.js 14 (App Router) + Tailwind CSS。黑白极简风格,参考 Vercel Ship London 的设计语言。

## 快速开始

```bash
# 安装依赖
npm install

# 本地开发
npm run dev
# → 打开 http://localhost:3000

# 生产构建
npm run build
npm run start
```

## 项目结构

```
.
├── app/
│   ├── globals.css        # 全局样式 + 滚动渐入 + 背景网格
│   ├── layout.tsx         # 根布局,引入 Geist 字体
│   └── page.tsx           # 主页面,组合所有模块
├── components/
│   ├── Nav.tsx            # 固定顶部导航(毛玻璃)
│   ├── Hero.tsx           # 首屏 + 实时时钟 meta
│   ├── LocalClock.tsx     # 本地时间(等宽字体,每秒跳动)
│   ├── Signal.tsx         # About Signal 四个关键词卡片
│   ├── Writing.tsx        # 文章横排列表
│   ├── Works.tsx          # Works Coming Soon 占位卡片
│   ├── Contact.tsx        # 双列联系卡片
│   ├── Footer.tsx         # 极简 footer
│   ├── SectionHead.tsx    # 通用 section 头部
│   └── RevealOnScroll.tsx # 滚动渐入逻辑(Intersection Observer)
├── tailwind.config.ts     # 设计 token:bg/fg/line 灰阶色板
└── next.config.js
```

## 设计 token

| token | 值 | 用途 |
|---|---|---|
| `bg` | `#000` | 背景 |
| `elev` | `#0a0a0a` | 卡片背景 |
| `fg` | `#fff` | 一级文字 |
| `fg-2` | `#a1a1a1` | 二级文字 |
| `fg-3` | `#666` | 三级文字 / meta |
| `line` | `rgba(255,255,255,0.08)` | 边框 |
| `line-hover` | `rgba(255,255,255,0.24)` | hover 边框 |

字体:Geist Sans + Geist Mono(从 Google Fonts 加载)。

## 内容定制

- Hero 标题:`components/Hero.tsx`
- 四个关键词:`components/Signal.tsx` 顶部 `signals` 数组
- 文章列表:`components/Writing.tsx` 顶部 `articles` 数组
- Works 占位:`components/Works.tsx` 顶部 `slots` 数组
- Contact 卡片:`components/Contact.tsx` 顶部 `links` 数组

## 部署

推荐 Vercel:`vercel deploy`,一条命令完成。
